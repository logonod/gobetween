#!/usr/bin/env bash
#
# List all current servers
#
curl -XDELETE "http://localhost:8888/servers/$1"
