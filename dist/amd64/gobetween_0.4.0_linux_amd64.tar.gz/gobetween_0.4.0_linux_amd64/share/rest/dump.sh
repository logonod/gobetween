#!/usr/bin/env bash
#
# List all current servers
#
curl -XGET "http://localhost:8888/dump"
